'use strict';

const { Arm, Sword, Bow, Staff, Knife, Axe, LongBow, StormStaff } = require('./weapon.js');

class Player {
  constructor(position, name) {
    this.life = 100;
    this.magic = 20;
    this.speed = 1;
    this.attack = 10;
    this.agility = 5;
    this.luck = 10;
    this.description = 'Игрок';
    this.weapon = new Arm();
    this.position = position;
    this.name = name;
    this.hitCount = 0;
  }

  getLuck() {
    return (Math.random() + this.luck) / 100;
  }

  getDamage(distance) {
    if (distance > this.weapon.range) return 0;
    return (this.attack + this.weapon.getDamage()) * this.getLuck() / distance;
  }

  takeDamage(damage) {
    this.life = Math.max(0, this.life - damage);
  }

  isDead() {
    return this.life === 0;
  }

  moveLeft(distance) {
    const actualDistance = Math.min(distance, this.speed);
    this.position = Math.max(0, this.position - actualDistance);
  }

  moveRight(distance) {
    const actualDistance = Math.min(distance, this.speed);
    this.position += actualDistance;
  }

  move(distance) {
    if (distance < 0) {
      this.moveLeft(Math.abs(distance));
    } else {
      this.moveRight(distance);
    }
  }

  isAttackBlocked() {
    return this.getLuck() > (100 - this.luck) / 100;
  }

  dodged() {
    return this.getLuck() > (100 - this.agility - this.speed * 3) / 100;
  }

  takeAttack(damage) {
    if (this.isAttackBlocked()) {
      this.weapon.takeDamage(damage);
      console.log(`${this.name} заблокировал удар! Оружие повреждено.`);
      return;
    }

    if (this.dodged()) {
      console.log(`${this.name} уклонился от удара!`);
      return;
    }

    this.takeDamage(damage);
    console.log(`${this.name} получил ${damage} урона. Жизнь: ${this.life}`);
  }

  checkWeapon() {
    const weaponMap = {
      'Sword': Sword,
      'Bow': Bow,
      'Staff': Staff,
      'Axe': Axe,
      'LongBow': LongBow,
      'StormStaff': StormStaff,
      'Knife': Knife,
      'Arm': Arm
    };

    const chains = {
      'Sword': ['Sword', 'Knife', 'Arm'],
      'Bow': ['Bow', 'Knife', 'Arm'],
      'Staff': ['Staff', 'Knife', 'Arm'],
      'Axe': ['Axe', 'Knife', 'Arm'],
      'LongBow': ['LongBow', 'Knife', 'Arm'],
      'StormStaff': ['StormStaff', 'Knife', 'Arm'],
      'Knife': ['Knife', 'Arm'],
      'Arm': ['Arm']
    };

    if (this.weapon.isBroken()) {
      const chain = chains[this.weapon.constructor.name] || ['Arm'];
      const currentIndex = chain.indexOf(this.weapon.constructor.name);
      const nextIndex = currentIndex + 1;
      if (nextIndex < chain.length) {
        const NextClass = weaponMap[chain[nextIndex]];
        if (NextClass) {
          this.weapon = new NextClass();
          console.log(`${this.name} сменил оружие на ${this.weapon.name}`);
        }
      }
    }
  }

  tryAttack(enemy) {
    const distance = Math.abs(this.position - enemy.position);
    if (distance > this.weapon.range) {
      console.log(`${this.name} не достаёт до ${enemy.name}`);
      return;
    }

    this.weapon.takeDamage(10 * this.getLuck());

    if (distance === 0) {
      const damage = this.getDamage(1) * 2;
      enemy.takeAttack(damage);
      enemy.moveRight(1);
      console.log(`${this.name} бьёт ${enemy.name} с удвоенной силой!`);
      return;
    }

    const damage = this.getDamage(distance);
    enemy.takeAttack(damage);
    console.log(`${this.name} атакует ${enemy.name} на ${damage.toFixed(2)} урона`);
  }

  chooseEnemy(players) {
    const alive = players.filter(p => !p.isDead() && p !== this);
    if (!alive.length) return null;
    return alive.reduce((a, b) => a.life < b.life ? a : b);
  }

  moveToEnemy(enemy) {
    if (!enemy) return;
    const dist = enemy.position - this.position;
    if (dist > 0) {
      this.moveRight(dist);
    } else if (dist < 0) {
      this.moveLeft(Math.abs(dist));
    }
  }

  turn(players) {
    if (this.isDead()) return;
    const enemy = this.chooseEnemy(players);
    if (!enemy) return;
    this.moveToEnemy(enemy);
    this.tryAttack(enemy);
    this.checkWeapon();
  }
}

module.exports = { Player };