'use strict';

const { Warrior, Archer, Mage, Dwarf, Crossbowman, Demiurge } = require('./classes.js');
const { play } = require('./battle.js');

const warrior = new Warrior(0, 'Алёша');
const archer = new Archer(5, 'Леголас');
const mage = new Mage(10, 'Гендальф');

play([warrior, archer, mage]);