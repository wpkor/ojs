'use strict';

const { Player } = require('./player.js');
const { Sword, Bow, Staff, Axe, LongBow, StormStaff } = require('./weapon.js');

class Warrior extends Player {
  constructor(position, name) {
    super(position, name);
    this.life = 120;
    this.speed = 2;
    this.attack = 10;
    this.description = 'Воин';
    this.weapon = new Sword();
  }

  takeDamage(damage) {
    if (this.life < 60 && this.getLuck() > 0.8 && this.magic > 0) {
      const magicDmg = Math.min(damage, this.magic);
      this.magic -= magicDmg;
      super.takeDamage(damage - magicDmg);
      console.log(`${this.name} поглотил ${magicDmg} урона маной. Осталось маны: ${this.magic}`);
    } else {
      super.takeDamage(damage);
    }
  }
}

class Archer extends Player {
  constructor(position, name) {
    super(position, name);
    this.life = 80;
    this.magic = 35;
    this.attack = 5;
    this.agility = 10;
    this.description = 'Лучник';
    this.weapon = new Bow();
  }

  getDamage(distance) {
    if (distance > this.weapon.range) return 0;
    return (this.attack + this.weapon.getDamage()) * this.getLuck() * distance / this.weapon.range;
  }
}

class Mage extends Player {
  constructor(position, name) {
    super(position, name);
    this.life = 70;
    this.magic = 100;
    this.attack = 5;
    this.agility = 8;
    this.description = 'Маг';
    this.weapon = new Staff();
  }

  takeDamage(damage) {
    if (this.magic > 50) {
      super.takeDamage(damage / 2);
      this.magic = Math.max(0, this.magic - 12);
      console.log(`${this.name} уменьшил урон до ${damage/2}. Мана: ${this.magic}`);
    } else {
      super.takeDamage(damage);
      console.log(`${this.name} получил ${damage} урона. Жизнь: ${this.life}`);
    }
  }
}

class Dwarf extends Warrior {
  constructor(position, name) {
    super(position, name);
    this.life = 130;
    this.attack = 15;
    this.luck = 20;
    this.description = 'Гном';
    this.weapon = new Axe();
    this.hitCount = 0; // Явно инициализируем счётчик
  }

  takeDamage(damage) {
    this.hitCount++;
    
    // Если 6-й удар и удача > 0.5
    if (this.hitCount % 6 === 0 && this.getLuck() > 0.5) {
      const reducedDamage = damage / 2;
      // Напрямую уменьшаем жизнь, минуя всю логику Warrior
      this.life = Math.max(0, this.life - reducedDamage);
      console.log(`${this.name} получил уменьшенный урон (${reducedDamage})! Осталось жизни: ${this.life}`);
    } else {
      // Используем логику Warrior для всех остальных ударов
      super.takeDamage(damage);
    }
  }
}

class Crossbowman extends Archer {
  constructor(position, name) {
    super(position, name);
    this.life = 85;
    this.attack = 8;
    this.agility = 20;
    this.luck = 15;
    this.description = 'Арбалетчик';
    this.weapon = new LongBow();
  }
}

class Demiurge extends Mage {
  constructor(position, name) {
    super(position, name);
    this.life = 80;
    this.magic = 120;
    this.attack = 6;
    this.luck = 12;
    this.description = 'Демиург';
    this.weapon = new StormStaff();
  }

  getDamage(distance) {
    if (distance > this.weapon.range) return 0;
    let damage = super.getDamage(distance);
    if (this.magic > 0 && this.getLuck() > 0.6) {
      damage *= 1.5;
      console.log(`${this.name} наносит увеличенный урон (x1.5)!`);
    }
    return damage;
  }
}

module.exports = {
  Warrior,
  Archer,
  Mage,
  Dwarf,
  Crossbowman,
  Demiurge
};