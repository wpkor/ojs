const { Player } = require('../player.js');
const { Arm, Sword, Knife } = require('../weapon.js');

describe('Player', () => {
  test('should create player with correct properties', () => {
    const p = new Player(5, 'Тест');
    expect(p.life).toBe(100);
    expect(p.magic).toBe(20);
    expect(p.speed).toBe(1);
    expect(p.attack).toBe(10);
    expect(p.agility).toBe(5);
    expect(p.luck).toBe(10);
    expect(p.description).toBe('Игрок');
    expect(p.weapon).toBeInstanceOf(Arm);
    expect(p.position).toBe(5);
    expect(p.name).toBe('Тест');
  });

  test('getLuck should return value between 0 and 1', () => {
    const p = new Player(0, 'Тест');
    jest.spyOn(Math, 'random').mockReturnValue(0.5);
    const luck = p.getLuck();
    expect(luck).toBe((0.5 + 10) / 100);
    expect(luck).toBeGreaterThanOrEqual(0);
    expect(luck).toBeLessThanOrEqual(1);
    jest.restoreAllMocks();
  });

  test('getDamage should return 0 if distance > range', () => {
    const p = new Player(0, 'Тест');
    expect(p.getDamage(2)).toBe(0);
  });

  test('getDamage should calculate correctly', () => {
    const p = new Player(0, 'Тест');
    jest.spyOn(p, 'getLuck').mockReturnValue(0.5);
    p.attack = 10;
    p.weapon.getDamage = jest.fn().mockReturnValue(5);
    expect(p.getDamage(1)).toBe(7.5);
  });

  test('takeDamage should not go below 0', () => {
    const p = new Player(0, 'Тест');
    p.takeDamage(30);
    expect(p.life).toBe(70);
    p.takeDamage(100);
    expect(p.life).toBe(0);
    p.takeDamage(50);
    expect(p.life).toBe(0);
  });

  test('isDead should return true when life is 0', () => {
    const p = new Player(0, 'Тест');
    expect(p.isDead()).toBe(false);
    p.takeDamage(150);
    expect(p.isDead()).toBe(true);
  });

  test('moveLeft should move but not more than speed', () => {
    const p = new Player(5, 'Тест');
    p.speed = 2;
    p.moveLeft(3);
    expect(p.position).toBe(3);
    p.moveLeft(10);
    expect(p.position).toBe(1);
  });

  test('moveRight should move but not more than speed', () => {
    const p = new Player(5, 'Тест');
    p.speed = 2;
    p.moveRight(3);
    expect(p.position).toBe(7);
    p.moveRight(10);
    expect(p.position).toBe(9);
  });

  test('move should call moveLeft or moveRight', () => {
    const p = new Player(5, 'Тест');
    p.speed = 2;
    jest.spyOn(p, 'moveLeft');
    jest.spyOn(p, 'moveRight');
    
    p.move(-3);
    expect(p.moveLeft).toHaveBeenCalledWith(3);
    
    p.move(3);
    expect(p.moveRight).toHaveBeenCalledWith(3);
  });

  test('isAttackBlocked should return boolean', () => {
    const p = new Player(0, 'Тест');
    jest.spyOn(p, 'getLuck').mockReturnValue(0.95);
    expect(p.isAttackBlocked()).toBe(true);
    jest.spyOn(p, 'getLuck').mockReturnValue(0.1);
    expect(p.isAttackBlocked()).toBe(false);
  });

  test('dodged should return boolean', () => {
    const p = new Player(0, 'Тест');
    p.agility = 10;
    p.speed = 2;
    jest.spyOn(p, 'getLuck').mockReturnValue(0.95);
    expect(p.dodged()).toBe(true);
    jest.spyOn(p, 'getLuck').mockReturnValue(0.1);
    expect(p.dodged()).toBe(false);
  });

  test('takeAttack should block and damage weapon', () => {
    const p = new Player(0, 'Тест');
    jest.spyOn(p, 'isAttackBlocked').mockReturnValue(true);
    jest.spyOn(p.weapon, 'takeDamage');
    jest.spyOn(console, 'log').mockImplementation(() => {});
    const initialLife = p.life;
    p.takeAttack(20);
    expect(p.weapon.takeDamage).toHaveBeenCalledWith(20);
    expect(p.life).toBe(initialLife);
  });

  test('takeAttack should dodge and take no damage', () => {
    const p = new Player(0, 'Тест');
    jest.spyOn(p, 'isAttackBlocked').mockReturnValue(false);
    jest.spyOn(p, 'dodged').mockReturnValue(true);
    jest.spyOn(console, 'log').mockImplementation(() => {});
    const initialLife = p.life;
    p.takeAttack(20);
    expect(p.life).toBe(initialLife);
  });

  test('takeAttack should take damage when not blocked or dodged', () => {
    const p = new Player(0, 'Тест');
    jest.spyOn(p, 'isAttackBlocked').mockReturnValue(false);
    jest.spyOn(p, 'dodged').mockReturnValue(false);
    jest.spyOn(console, 'log').mockImplementation(() => {});
    const initialLife = p.life;
    p.takeAttack(20);
    expect(p.life).toBe(initialLife - 20);
  });

  test('checkWeapon should change weapon when broken', () => {
    const p = new Player(0, 'Тест');
    p.weapon = new Sword();
    p.weapon.isBroken = jest.fn().mockReturnValue(true);
    jest.spyOn(console, 'log').mockImplementation(() => {});
    p.checkWeapon();
    expect(p.weapon.constructor.name).toBe('Knife');
  });

  test('checkWeapon should handle unknown weapon types', () => {
    const p = new Player(0, 'Тест');
    p.weapon = { 
      constructor: { name: 'Unknown' }, 
      isBroken: () => true 
    };
    jest.spyOn(console, 'log').mockImplementation(() => {});
    p.checkWeapon();
    expect(p.weapon.constructor.name).toBe('Arm');
  });

  test('tryAttack should not attack when distance > range', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(10, 'Враг');
    p.weapon = new Sword(); // range = 1
    jest.spyOn(enemy, 'takeAttack');
    jest.spyOn(console, 'log').mockImplementation(() => {});
    p.tryAttack(enemy);
    expect(enemy.takeAttack).not.toHaveBeenCalled();
  });

  test('tryAttack should deal double damage when distance === 0', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(0, 'Враг');
    p.attack = 10;
    p.weapon = new Sword(); // range = 1
    p.weapon.getDamage = jest.fn().mockReturnValue(5);
    jest.spyOn(p, 'getLuck').mockReturnValue(0.5);
    jest.spyOn(enemy, 'takeAttack');
    jest.spyOn(enemy, 'moveRight');
    jest.spyOn(console, 'log').mockImplementation(() => {});
    p.tryAttack(enemy);
    expect(enemy.takeAttack).toHaveBeenCalled();
    expect(enemy.moveRight).toHaveBeenCalledWith(1);
  });

  test('tryAttack should deal normal damage when distance > 0 and within range', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(1, 'Враг'); // distance = 1, range = 1
    p.attack = 10;
    p.weapon = new Sword(); // range = 1
    p.weapon.getDamage = jest.fn().mockReturnValue(5);
    jest.spyOn(p, 'getLuck').mockReturnValue(0.5);
    jest.spyOn(enemy, 'takeAttack');
    jest.spyOn(console, 'log').mockImplementation(() => {});
    p.tryAttack(enemy);
    expect(enemy.takeAttack).toHaveBeenCalled();
  });

  test('chooseEnemy should return null when no enemies', () => {
    const p = new Player(0, 'Тест');
    const players = [p];
    expect(p.chooseEnemy(players)).toBeNull();
  });

  test('chooseEnemy should return enemy with lowest life', () => {
    const p = new Player(0, 'Тест');
    const enemy1 = new Player(5, 'Враг1');
    const enemy2 = new Player(10, 'Враг2');
    enemy1.life = 30;
    enemy2.life = 50;
    const players = [p, enemy1, enemy2];
    expect(p.chooseEnemy(players)).toBe(enemy1);
  });

  test('moveToEnemy should move right when enemy is to the right', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(5, 'Враг');
    p.speed = 2;
    p.moveToEnemy(enemy);
    expect(p.position).toBe(2);
  });

  test('moveToEnemy should move left when enemy is to the left', () => {
    const p = new Player(10, 'Тест');
    const enemy = new Player(3, 'Враг');
    p.speed = 2;
    p.moveToEnemy(enemy);
    expect(p.position).toBe(8);
  });

  test('moveToEnemy should do nothing when enemy is null', () => {
    const p = new Player(0, 'Тест');
    const oldPosition = p.position;
    p.moveToEnemy(null);
    expect(p.position).toBe(oldPosition);
  });

  test('turn should do nothing when player is dead', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(5, 'Враг');
    p.life = 0;
    jest.spyOn(p, 'chooseEnemy');
    p.turn([p, enemy]);
    expect(p.chooseEnemy).not.toHaveBeenCalled();
  });

  test('turn should do nothing when no enemies', () => {
    const p = new Player(0, 'Тест');
    jest.spyOn(p, 'chooseEnemy').mockReturnValue(null);
    jest.spyOn(p, 'moveToEnemy');
    jest.spyOn(p, 'tryAttack');
    p.turn([p]);
    expect(p.moveToEnemy).not.toHaveBeenCalled();
    expect(p.tryAttack).not.toHaveBeenCalled();
  });

  test('turn should execute full turn when enemy exists', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(5, 'Враг');
    jest.spyOn(p, 'chooseEnemy').mockReturnValue(enemy);
    jest.spyOn(p, 'moveToEnemy');
    jest.spyOn(p, 'tryAttack');
    jest.spyOn(p, 'checkWeapon');
    jest.spyOn(console, 'log').mockImplementation(() => {});
    p.turn([p, enemy]);
    expect(p.moveToEnemy).toHaveBeenCalledWith(enemy);
    expect(p.tryAttack).toHaveBeenCalledWith(enemy);
    expect(p.checkWeapon).toHaveBeenCalled();
  });

  test('moveToEnemy should move right when enemy is to the right with distance > speed', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(10, 'Враг');
    p.speed = 2;
    p.moveToEnemy(enemy);
    expect(p.position).toBe(2);
  });

  test('moveToEnemy should move left when enemy is to the left with distance > speed', () => {
    const p = new Player(10, 'Тест');
    const enemy = new Player(0, 'Враг');
    p.speed = 2;
    p.moveToEnemy(enemy);
    expect(p.position).toBe(8);
  });

  test('moveToEnemy should move exactly to enemy when distance <= speed', () => {
    const p = new Player(3, 'Тест');
    const enemy = new Player(5, 'Враг');
    p.speed = 3;
    p.moveToEnemy(enemy);
    expect(p.position).toBe(5);
  });

  test('tryAttack should reduce weapon durability', () => {
    const p = new Player(0, 'Тест');
    const enemy = new Player(1, 'Враг');
    p.attack = 10;
    p.weapon = new Sword(); // range = 1
    p.weapon.getDamage = jest.fn().mockReturnValue(5);
    jest.spyOn(p, 'getLuck').mockReturnValue(0.5);
    jest.spyOn(p.weapon, 'takeDamage');
    jest.spyOn(console, 'log').mockImplementation(() => {});
    p.tryAttack(enemy);
    expect(p.weapon.takeDamage).toHaveBeenCalledWith(10 * 0.5);
  });
});