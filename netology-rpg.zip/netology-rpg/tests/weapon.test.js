const { Weapon, Arm, Bow, Sword, Knife, Staff, LongBow, Axe, StormStaff } = require('../weapon.js');

describe('Weapon', () => {
  test('should create weapon with correct properties', () => {
    const w = new Weapon('Test', 10, 100, 2);
    expect(w.name).toBe('Test');
    expect(w.attack).toBe(10);
    expect(w.durability).toBe(100);
    expect(w.initDurability).toBe(100);
    expect(w.range).toBe(2);
  });

  test('takeDamage should reduce durability but not below 0', () => {
    const w = new Weapon('Test', 10, 100, 2);
    w.takeDamage(30);
    expect(w.durability).toBe(70);
    w.takeDamage(100);
    expect(w.durability).toBe(0);
    w.takeDamage(50);
    expect(w.durability).toBe(0);
  });

  test('getDamage should work correctly', () => {
    const w = new Weapon('Test', 10, 100, 2);
    expect(w.getDamage()).toBe(10);
    w.takeDamage(60);
    expect(w.getDamage()).toBe(10);
    w.takeDamage(15);
    expect(w.getDamage()).toBe(5);
    w.takeDamage(50);
    expect(w.getDamage()).toBe(0);
  });

  test('isBroken should return true when durability is 0', () => {
    const w = new Weapon('Test', 10, 100, 2);
    expect(w.isBroken()).toBe(false);
    w.takeDamage(150);
    expect(w.isBroken()).toBe(true);
  });

  test('Arm should have Infinity durability', () => {
    const arm = new Arm();
    expect(arm.durability).toBe(Infinity);
    arm.takeDamage(50);
    expect(arm.durability).toBe(Infinity);
  });

  test('Bow should have correct stats', () => {
    const bow = new Bow();
    expect(bow.name).toBe('Лук');
    expect(bow.attack).toBe(10);
    expect(bow.durability).toBe(200);
    expect(bow.range).toBe(3);
  });

  test('Sword should have correct stats', () => {
    const sword = new Sword();
    expect(sword.name).toBe('Меч');
    expect(sword.attack).toBe(25);
    expect(sword.durability).toBe(500);
    expect(sword.range).toBe(1);
  });

  test('Knife should have correct stats', () => {
    const knife = new Knife();
    expect(knife.name).toBe('Нож');
    expect(knife.attack).toBe(5);
    expect(knife.durability).toBe(300);
    expect(knife.range).toBe(1);
  });

  test('Staff should have correct stats', () => {
    const staff = new Staff();
    expect(staff.name).toBe('Посох');
    expect(staff.attack).toBe(8);
    expect(staff.durability).toBe(300);
    expect(staff.range).toBe(2);
  });

  test('LongBow should have correct stats', () => {
    const lb = new LongBow();
    expect(lb.name).toBe('Длинный лук');
    expect(lb.attack).toBe(15);
    expect(lb.range).toBe(4);
    expect(lb.durability).toBe(200);
  });

  test('Axe should have correct stats', () => {
    const axe = new Axe();
    expect(axe.name).toBe('Секира');
    expect(axe.attack).toBe(27);
    expect(axe.durability).toBe(800);
    expect(axe.initDurability).toBe(800);
    expect(axe.range).toBe(1);
  });

  test('StormStaff should have correct stats', () => {
    const ss = new StormStaff();
    expect(ss.name).toBe('Посох Бури');
    expect(ss.attack).toBe(10);
    expect(ss.range).toBe(3);
    expect(ss.durability).toBe(300);
  });
});