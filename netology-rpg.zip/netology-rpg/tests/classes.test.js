const { Warrior, Archer, Mage, Dwarf, Crossbowman, Demiurge } = require('../classes.js');
const { Sword, Bow, Staff, Axe, LongBow, StormStaff } = require('../weapon.js');

describe('Warrior', () => {
  test('should create warrior with correct properties', () => {
    const w = new Warrior(0, 'Алёша');
    expect(w.life).toBe(120);
    expect(w.speed).toBe(2);
    expect(w.attack).toBe(10);
    expect(w.description).toBe('Воин');
    expect(w.weapon).toBeInstanceOf(Sword);
  });

  test('takeDamage should use magic when conditions met', () => {
    const w = new Warrior(0, 'Алёша');
    w.life = 50;
    w.magic = 20;
    jest.spyOn(w, 'getLuck').mockReturnValue(0.9);
    jest.spyOn(console, 'log').mockImplementation(() => {});
    w.takeDamage(15);
    expect(w.magic).toBe(5);
    expect(w.life).toBe(50);
  });

  test('takeDamage should not use magic when luck low', () => {
    const w = new Warrior(0, 'Алёша');
    w.life = 50;
    w.magic = 20;
    jest.spyOn(w, 'getLuck').mockReturnValue(0.7);
    jest.spyOn(console, 'log').mockImplementation(() => {});
    w.takeDamage(15);
    expect(w.magic).toBe(20);
    expect(w.life).toBe(35);
  });
});

describe('Archer', () => {
  test('should create archer with correct properties', () => {
    const a = new Archer(0, 'Леголас');
    expect(a.life).toBe(80);
    expect(a.magic).toBe(35);
    expect(a.agility).toBe(10);
    expect(a.weapon).toBeInstanceOf(Bow);
  });

  test('getDamage should use special formula', () => {
    const a = new Archer(0, 'Леголас');
    a.attack = 5;
    a.weapon.getDamage = jest.fn().mockReturnValue(10);
    a.weapon.range = 3;
    jest.spyOn(a, 'getLuck').mockReturnValue(0.5);
    expect(a.getDamage(2)).toBe((5 + 10) * 0.5 * 2 / 3);
  });
});

describe('Mage', () => {
  test('should create mage with correct properties', () => {
    const m = new Mage(0, 'Гендальф');
    expect(m.life).toBe(70);
    expect(m.magic).toBe(100);
    expect(m.weapon).toBeInstanceOf(Staff);
  });

  test('takeDamage should reduce damage when magic > 50', () => {
    const m = new Mage(0, 'Гендальф');
    m.magic = 80;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    m.takeDamage(20);
    expect(m.life).toBe(60);
    expect(m.magic).toBe(68);
  });

  test('takeDamage should not reduce damage when magic <= 50', () => {
    const m = new Mage(0, 'Гендальф');
    m.magic = 40;
    jest.spyOn(console, 'log').mockImplementation(() => {});
    m.takeDamage(20);
    expect(m.life).toBe(50);
    expect(m.magic).toBe(40);
  });
});

describe('Dwarf', () => {
  test('should create dwarf with correct properties', () => {
    const d = new Dwarf(0, 'Гимли');
    expect(d.life).toBe(130);
    expect(d.attack).toBe(15);
    expect(d.luck).toBe(20);
    expect(d.weapon).toBeInstanceOf(Axe);
  });

  test('takeDamage should reduce on every 6th hit', () => {
    const d = new Dwarf(0, 'Гимли');
    d.life = 120;
    jest.spyOn(d, 'getLuck').mockReturnValue(0.8);
    jest.spyOn(console, 'log').mockImplementation(() => {});
    
    d.takeDamage(20);
    expect(d.life).toBe(100);
    d.takeDamage(20);
    expect(d.life).toBe(80);
    d.takeDamage(20);
    expect(d.life).toBe(60);
    d.takeDamage(20);
    expect(d.life).toBe(40);
    d.takeDamage(20);
    expect(d.life).toBe(20);
    d.takeDamage(20);
    expect(d.life).toBe(10);
  });
});

describe('Crossbowman', () => {
  test('should create crossbowman with correct properties', () => {
    const c = new Crossbowman(0, 'Арбалетчик');
    expect(c.life).toBe(85);
    expect(c.attack).toBe(8);
    expect(c.agility).toBe(20);
    expect(c.luck).toBe(15);
    expect(c.weapon).toBeInstanceOf(LongBow);
  });
});

describe('Demiurge', () => {
  test('should create demiurge with correct properties', () => {
    const d = new Demiurge(0, 'Демиург');
    expect(d.life).toBe(80);
    expect(d.magic).toBe(120);
    expect(d.attack).toBe(6);
    expect(d.luck).toBe(12);
    expect(d.weapon).toBeInstanceOf(StormStaff);
  });

  test('getDamage should increase when conditions met', () => {
    const d = new Demiurge(0, 'Демиург');
    d.magic = 50;
    jest.spyOn(d, 'getLuck').mockReturnValue(0.7);
    jest.spyOn(d, 'getDamage').mockImplementation(function(distance) {
      if (distance > this.weapon.range) return 0;
      let damage = 10;
      if (this.magic > 0 && this.getLuck() > 0.6) damage *= 1.5;
      return damage;
    });
    expect(d.getDamage(1)).toBe(15);
  });
});