'use strict';

function play(players) {
  console.log('=== НАЧАЛО БИТВЫ ===');
  let turn = 0;

  while (true) {
    const alive = players.filter(p => !p.isDead());

    if (alive.length <= 1) {
      const winner = alive[0] || null;
      if (winner) {
        console.log(`\n ПОБЕДИТЕЛЬ: ${winner.name} (${winner.description})`);
      } else {
        console.log('=== НИЧЬЯ ===');
      }
      return winner;
    }

    turn++;
    console.log(`\n--- Ход ${turn} ---`);
    console.log(`Живых игроков: ${alive.length}`);

    alive.forEach(player => {
      if (!player.isDead()) {
        player.turn(players);
      }
    });

    alive.forEach(player => {
      console.log(`${player.name} (${player.description}): Жизнь=${player.life.toFixed(2)}, Мана=${player.magic.toFixed(2)}, Позиция=${player.position}`);
    });
  }
}

module.exports = { play };